import os
from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():

    return LaunchDescription([

        Node(
            package='ldlidar_stl_ros2',
            output='screen',
            parameters=[{
                'port_name': '/dev/ttyUSB1',
                'frame_id': 'laser_frame',
                'topic_name': 'scan',
                
            }]
        )
    ])
